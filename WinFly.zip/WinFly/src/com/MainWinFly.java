package com;

import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Timer;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

class A implements Runnable {
	@Override
	public void run() {

	}
}

public class MainWinFly extends JFrame {
	private final int SIZE = 500;
	private JFrame f;
	private static JPanel p;
	private Timer timer;
	private static int x = 250;
	private static int y = 250;
	Graphics g;
	static Bee[] bees;
	private static BufferedImage image;

	public static Coord getWinFlyCoord() {
		return new Coord(x, y);
	}

	public static void main(String[] args) throws Exception {
		try {
			image = ImageIO.read(new File("whiteBg.png"));
		} catch (IOException ex) {
			// handle exception...
		}
		new MainWinFly();
		Runnable runnable = new A();
		Thread thread = new Thread(runnable);
		thread.start();
		int i= 0;
		while(true) {
			MainWinFly.doRandomMoves();
			if (i % 40 == 0)
				MainWinFly.movesToMouse();
			try {
				Thread.sleep(5);

			} catch (InterruptedException e) {
				throw new IllegalStateException(e);
			}
			i++;
		}

	}

	private MainWinFly() {
		initPanel();
	}

	private void initPanel() {
		f = new JFrame();
		f.setSize(SIZE, SIZE);
		f.setResizable(false);

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		bees = new Bee[250];
		for (int i = 0; i < bees.length; i++) {
			bees[i] = new Bee();
		}

		p = new JPanel() {

			@Override
			protected void paintComponent(Graphics g) {
				g.drawImage(image, 0, 0, this);

				for (int i = 0; i < bees.length; i++) {
					g.drawRect(bees[i].getX(), bees[i].getY(), bees[i].rectangle.height, bees[i].rectangle.width);
				}
			}
		};

		f.add(p);

		p.addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				x = e.getX();
				y = e.getY();
				System.out.println(x + ", " + y);
				movesToMouseEasy();
				p.repaint();
			}
		});
		f.setVisible(true);
	}

	public static void movesToMouseEasy() {
		for (int i = 0; i < bees.length; i++) {
			bees[i].moveToMouseEasy();
		}
		
	}

	public static void movesToMouse() {
		for (int i = 0; i < bees.length; i++) {
			bees[i].moveToMouse();
		}
		
	}

	public static void doRandomMoves() {
		for (Bee bee : bees) {
			bee.doRandomMove();
			p.repaint();
		}
	}
}
