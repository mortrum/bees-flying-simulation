package com;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.Random;

import javax.swing.JComponent;

public class Bee extends JComponent {
	private int x;
	private int y;
	Rectangle rectangle;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	Random random = new Random();

	public Bee() {
		x = random.nextInt(500);
		y = random.nextInt(500);
		rectangle = new Rectangle(x, y, 5, 5);
	}

	@Override
	public String toString() {
		return "Bee [x=" + x + ", y=" + y + ", rectangle=" + rectangle + "]";
	}

	public static void main(String[] args) {
		System.out.println(new Bee());
	}

	public void moveToMouse() {
		int winFlyX = MainWinFly.getWinFlyCoord().x;
		int winFlyY = MainWinFly.getWinFlyCoord().y;
		Random random = new Random();
		int factorX = (Math.abs(this.x - winFlyX) / 10) + 1;
		int factorY = (Math.abs(this.y - winFlyY) / 10) + 1;

		if (winFlyX > x)
			x += random.nextInt(5) * factorX;
		else
			x -= random.nextInt(5) * factorX;
		if (winFlyY > y)
			y += random.nextInt(5) * factorY;
		else
			y -= random.nextInt(5) * factorY;
	}

	public void doRandomMove() {
		// Random random = new Random(47);
		int x = random.nextInt(10);
		int y = random.nextInt(10);
		x -= 5;
		y -= 5;
		this.x += x;
		this.y += y;

		if (this.x > 500)
			this.x -= 500;
		if (this.x < 0)
			this.x += 500;
		if (this.y > 500)
			this.y -= 500;
		if (this.y < 0)
			this.y += 500;

	}

	public void moveToMouseEasy() {
		int winFlyX = MainWinFly.getWinFlyCoord().x;
		int winFlyY = MainWinFly.getWinFlyCoord().y;
		Random random = new Random();
		int factorX = (Math.abs(this.x - winFlyX) / 70) + 1;
		int factorY = (Math.abs(this.y - winFlyY) / 70) + 1;

		if (winFlyX > x)
			x += random.nextInt(2) * factorX;
		else
			x -= random.nextInt(2) * factorX;
		if (winFlyY > y)
			y += random.nextInt(2) * factorY;
		else
			y -= random.nextInt(2) * factorY;

	}
}
